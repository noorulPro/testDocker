module oxyapp

greet() = print("Hello World!")

end # module oxyapp
