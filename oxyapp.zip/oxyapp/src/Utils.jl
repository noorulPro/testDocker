module Utils 

export sum_values

function sum_values(data_input)
    return sum(data_input)
end

end